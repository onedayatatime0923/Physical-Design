
#include "misc/global.hpp"

#ifndef data__dbGlobal_h
#define data__dbGlobal_h

enum Direction {
    UP, DOWN, LEFT, RIGHT
};

#endif
