1. 學號：B04901035	
2. 姓名：陳明宏
3. 使用之程式語言：< C++ >
4. 使用之編譯器：< GNU g++ >
5. 檔案壓縮方式: <zip -r b04901035-pa2.zip ./*>
6. 各檔案說明：
	 gr
	 include/sparsehash/dense_hash_map
	 include/sparsehash/dense_hash_set
	 include/sparsehash/sparse_hash_map
	 include/sparsehash/sparse_hash_set
	 include/sparsehash/sparsetable
	 include/sparsehash/template_util.h
	 include/sparsehash/type_traits.h
	 include/sparsehash/internal/densehashtable.h
	 include/sparsehash/internal/hashtable-common.h
	 include/sparsehash/internal/libc_allocator_with_realloc.h
	 include/sparsehash/internal/sparseconfig.h
	 include/sparsehash/internal/sparsehashtable.h
	 src/dataStructure/disjointSet.hpp
	 src/dataStructure/dsGlobal.hpp
	 src/dataStructure/hash.hpp
	 src/dataStructure/kdtree.hpp
	 src/dataStructure/nanoflann.hpp
	 src/dataStructure/pqueue.hpp
	 src/db/capacityTable.cpp
	 src/db/capacityTable.hpp
	 src/db/db.cpp
	 src/db/db.hpp
	 src/dbGlobal.hpp
	 src/net.cpp
	 src/net.hpp
	 src/point.hpp
	 src/segment.hpp
	 src/drAstar.cpp
	 src/drAstar.hpp
	 src/main.cpp
	 src/misc/global.cpp
	 src/misc/global.hpp
	 src/parser/io.cpp
	 src/parser/io.hpp
	 src/parser/mst.cpp
	 src/parser/mst.hpp
	 src/parser/parser.hpp
	 src/parser/routingdb.cpp
	 src/parser/routingdb.hpp
	 src/parser/tree.cpp
	 src/parser/tree.hpp
	 report.doc
	 readme.txt
	 CMakeLists.txt

7. 編譯方式說明：        	
	請先 mkdir build 再使用 cmake .. 再執行 make
	 
8. 執行、使用方式說明：

   	./gr [input file name] [output file name]       