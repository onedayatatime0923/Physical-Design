#ifndef ds__dsGlobal_h
#define ds__dsGlobal_h

#include "misc/global.hpp"

#endif 
